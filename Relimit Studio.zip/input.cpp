//Here we go, this is the file that will get the user input.
#include "stdafx.h"
#include "engine.h"
 
void Engine::input()//namespace
{
    // Handle the player quitting
    if (Keyboard::isKeyPressed(Keyboard::Escape))//this is saying if the escape button is pressed, then close the game.
    {
        m_Window.close();//this is telling the program to close the game.
    }
 
    // Handle the player moving
    if (Keyboard::isKeyPressed(Keyboard::A))//this is saying if the a key is pressed then Bob our character will move left.
    {
        m_Bob.moveLeft();//This is telling the program to make our character move left. 
			//wait, we never include bob.cpp????? thats what you might be thinking.
			//well actually we did. lets break it down.
			/*
			in engine.h we include bob.cpp. then we called upon Bob and a named it m_Bob
			in this file we include engine.h which we called upon m_Bob which calls upon Bob.cpp
			Weird right? Well welcome to programming where nothing makes senses.
			*/
    }
    else//this is an else statement. and else statement does have an condition, but doesn't want the condition. basically it will be the opposite of whatever if is
			//example if my condition for an if statement was "if(x <= 5){}" this means if x is less than or equal to 5, then run the code in the {}
			//what else does is if x is not less than or equal to 5, then it will run the code in the else {}
    {
        m_Bob.stopLeft();//this is telling the program that if the a key is not pressed, then stop moving left.
    }
 
    if (Keyboard::isKeyPressed(Keyboard::D))//What this is saying that if the d key is pressed, then Bob will move right
    {
        m_Bob.moveRight();// this is telling the program to make Bob move right.
    }
    else
    {
        m_Bob.stopRight();//this is telling the program that if the d key is not pressed, then stop moving right.
    }                       
 
}
//WHEN YOUR DONE READING THIS AND WRITING, THEN GO TO update.cpp FILE!!!