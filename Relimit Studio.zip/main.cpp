//what is a main file?
//its a file that runs everything. how programming works is your run one file to run a lot of files. thats this file. this file will run the engine and the game.
#include "stdafx.h"
#include "Engine.h"
 
int main()
{
    // Declare an instance of Engine
    Engine engine;
 
    // Start the engine
    engine.start();
 
    // Quit in the usual way when the engine is stopped
    return 0;//anything that returns to 0 will end the program.
}
//AFTER YOU DONE READING AND WRITING, THEN GO TO . what we are done. that was quicker than i thought. 
//anyways. will make you assignments to do before we start meeting. if you are struggling, or something does not make since @me or dm me on discord, and i will try to get back to you as soon as i can.
//the first assignments is to make a program similar to this one. but you will have a character that can move right, left, and jump up,
//make sure you put your name on your program. i would prefer that your name is on the main.cpp file.
//When your done turn it in to me. and i will look at it and see if i can blow it up -w-!!!