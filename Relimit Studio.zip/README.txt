This Repo is to teach you how to use c++ to make a game engine, as well how to use the git command. 
You will also be getting assignments, and a test. these are for me, so I know who needs more help, or I can trust to write a lot of code without my supervision.
-First thing you need is an ide, I would recommend vs(Visual Studio) or vsc(Visual Studio Code).
-Second thing you need is the game engine package.

Basic Coding things:
-// is a single line comment. 
you can use this to write a comment on something, or you can "comment out" piece of code. 
A Comment does not affect the code in anyway.
-/**/ is a block comment. its similar to the single line comment, but it allows you to cover more range.
This also does not affect the code in anyway.
-Make sure you read the comments in the files.
-when a word is capitalized, then was a lowercase word like this:
Transform transformTest = 15;
Transform <= is a method from another file.
transformTest <= is the variable name.
-A String is a sentence like this, in order to use a String, you have to put in a "".
-A Method is an action that can be "called upon" in or outside the file its in depending on if its a private or public method.
-C++ is a High-level Language, this means the language is really strict. so when its the code is not a method or class or a statement,
it will have to end with a ; for that line.

*First GO to the Bob.h file and start reading the comments and write code you see to your own bob.h file.