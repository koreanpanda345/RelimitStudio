#include "stdafx.h"
#include "engine.h"
 
Engine::Engine()//remember this is a namespace. we are giving the Class Engine() the name Engine to be called upon.
{
    // Get the screen resolution and create an SFML window and View
    Vector2f resolution;
    resolution.x = VideoMode::getDesktopMode().width;
    resolution.y = VideoMode::getDesktopMode().height;
 
    m_Window.create(VideoMode(resolution.x, resolution.y),
        "Simple Game Engine",
        Style::Fullscreen);
 
    // Load the background into the texture
    // Be sure to scale this image to your screen size
    m_BackgroundTexture.loadFromFile("background.jpg");
 
    // Associate the sprite with the texture
    m_BackgroundSprite.setTexture(m_BackgroundTexture);
 
}
 
void Engine::start()//we are adding on to the start method in engine.h
{
    // Timing
    Clock clock;
 
    while (m_Window.isOpen())//this is a while loop. a while loop has the same structure as an if statement, however it will keep running this statement if the condition is true, if its false then it will not run.
    {
        // Restart the clock and save the elapsed time into dt
        Time dt = clock.restart();
 
        // Make a fraction from the delta time
        float dtAsSeconds = dt.asSeconds();
 
        input();
        update(dtAsSeconds);
        draw();
    }
}
//WHEN YOUR DOING READING AND WRITING, GO TO THE input.cpp FILE!!!