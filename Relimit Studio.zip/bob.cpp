//YOUR INCLUDED FILES
#include "stdafx.h"//Most .cpp files has this file included in it.
#include "Bob.h"//This is the file you just made.
 
Bob::Bob()//This is a namespace. We are "calling upon" the Bob class that we made,
          //and we are calling it Bob, so now everytime we call Bob, we are referring to the Bob class.
{
	//Remember the Private variables you made? Well I lied to you, You can Access a Priavte variables,
	//if its in a class.Since the private variables are in the Bob Class, and we used a  namespace,
	//which we can access it and set the variables to whatever we want, and the bob.h file will lock it so the player can not change the variables.
    // How fast does Bob move?
    m_Speed = 400;//this is telling the program that the variable m_Speed is equal to 400. since this is a private variable, m_Speed will only be 400, unless you change it in the code.
 
    // Associate a texture with the sprite
	//when you see a this:
    m_Texture.loadFromFile("bob.png");
	//this is calling on a method thats in another file.
	//to remember this, is file.method();
	//you probably noticed thats something in the (). this is allowed.
    m_Sprite.setTexture(m_Texture);     
    // Set the Bob's starting position
    m_Position.x = 500;
    m_Position.y = 800;
 
}
 
// Make the private spite available to the draw() function
Sprite Bob::getSprite()//This is Reassigning the method Bob::getSprite() to a Sprite
{
    return m_Sprite;
}
 
void Bob::moveLeft()
{
    m_LeftPressed = true;
}
 
void Bob::moveRight()
{
    m_RightPressed = true;
}
 
void Bob::stopLeft()
{
    m_LeftPressed = false;
}
 
void Bob::stopRight()
{
    m_RightPressed = false;
}
 
// Move Bob based on the input this frame,
// the time elapsed, and the speed
void Bob::update(float elapsedTime)//Update Method is the most important method when it comes to the game, this method updates every frame.
{
    if (m_RightPressed)//this is an if statement. an if statement as one really important role which is conditional.
			//the structure of an if statement is 
			//if(conditional){
			// then do this;
			//}
    {
        m_Position.x += m_Speed * elapsedTime;
    }
 
    if (m_LeftPressed)
    {
        m_Position.x -= m_Speed * elapsedTime;
    }
 
    // Now move the sprite to its new position
    m_Sprite.setPosition(m_Position);   
 
}
//AFTER YOU DONE READING THIS AND WRITE THIS CODE GO TO engine.h FILE