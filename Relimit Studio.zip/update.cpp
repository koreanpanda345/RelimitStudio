//what is an Update file do? no it does not update the actually game. well it actually kinda of does.
//What it does is it updates per frame. so if an action happens like bob moving, thats called an update, so we have to make a file to update every frame to allow movements.
#include "stdafx.h"
#include "engine.h"
 
using namespace sf;
 
void Engine::update(float dtAsSeconds)
{
    m_Bob.update(dtAsSeconds);//this is telling the program when to update bob.
}
//AFTER YOUR DONE READING AND WRITING, GO TO draw.cpp FILE.